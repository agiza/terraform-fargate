

This directory contains all of the top-level Terraform files for creating individual Modules within your terraform. 


First Clone and Clean: 

    #!/bin/bash -ex

    git clone https://github.com/g2technologygroup/g2-terraform-template.git
    rm -rf g2-terraform-template/.git

<b>Creating Terraform Backend with .tfstate  - Pre-requisites</b>

  You must have Terraform installed on your computer.
  You must have an Amazon Web Services (AWS) account.

Create a main.tf file in a new folder - and specify aws as the provider. 
    
    provider "aws"  {
      region = "us-east-1"
    }

Create an S3 Bucket: 

    resource "aws_s3_bucket" "terraform_state" {
      bucket = "terraform-up-and-running-state"

      versioning {
      enabled = true
    }

      lifecycle {
      prevent_destroy = true
      }
    }


Configure your AWS access keys as environment variables:

    export AWS_ACCESS_KEY_ID=(your access key id)
    export AWS_SECRET_ACCESS_KEY=(your secret access key)
    
You may want to specify a name for your bucket in vars.tf using the default parameter:

    variable "bucket_name" {
      description = "The name of the S3 bucket. Must be globally unique."
      default = "(YOUR_BUCKET_NAME)"
    }


Creating the S3 as a remote Configuration: 

    terraform remote config \
      -backend-config="bucket=(YOUR_BUCKET_NAME)" \
      -backend-config="key=global/s3/terraform.tfstate" \
      -backend-config="region=us-east-1" \
      -backend-config="encrypt=true"



Validate the templates:

    terraform plan

Deploy the code:

    terraform apply

Clean up when you're done:

    terraform destroy



