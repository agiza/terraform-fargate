CloudWatch Metrics and Alerts
=============================
Creates a SNS Topic for sending alerts to and then creates CloudWatch Metrics and Alerts to comply with CIS 3.x
