# Copyright Cloud Technology Partners
# Description: Lambda function that sends notification on AWS CloudTrail changes and when a trail gets disabled it re-enables it back.
#
# Cloudtraillambdamonitor.py


import json
import time
import boto3
import logging
import os
import botocore.session
from botocore.exceptions import ClientError
session = botocore.session.get_session()

logging.basicConfig(level=logging.DEBUG)
logger=logging.getLogger(__name__)

# Defines Lambda function for automatically enabling AWS CloudTrail logs when it gets disabled
# and publish notification to SNS Topic on any changes to the AWS CloudTrail.

def lambda_handler(event, context):
	logger.setLevel(logging.DEBUG)
	eventname = event['detail']['eventName']
	snsARN = os.environ['SNSARN']          #Getting the SNS Topic ARN passed in by the environment variables.
	logger.debug("Event is-- %s" %event)
	logger.debug("Event Name is--- %s" %eventname)
	logger.debug("SNSARN is-- %s" %snsARN)
	snsclient = boto3.client('sns')

# If the CloudTrail Logging is disabled we will send a notification for that
# and revert it back to enabled state. Note:- This automatic starting of logging will generate another SNS notification.

	if (eventname == 'StopLogging'):
	    cloudtrailArn= event['detail']['requestParameters']['name']
	    logger.info("AWS CloudTrail logging disabled for AWS Cloudtrail with ARN-- %s. Enabling the AWS Cloudtrail back again....." %cloudtrailArn)

	    #Sending the notification that the AWS CloudTrail has been disabled.
	    snspublish = snsclient.publish(
	                     TargetArn = snsARN,
	                     Subject=("CloudTrail event- \"%s\" received. Will automatically enable logging." %eventname),
	                     Message=json.dumps({'default': json.dumps(event)}),
	                     MessageStructure='json')

	   #Enabling the AWS CloudTrail logging

	    try:
	        client = boto3.client('cloudtrail')
	        enablelogging = client.start_logging(Name=cloudtrailArn)
	        logger.debug("Response on enable CloudTrail logging- %s" %enablelogging)

	    except ClientError as e:
	       logger.error("An error occured: %s" %e)

# Anything other than "StopLogging" event such as update, add/remove tags, create new trail etc.
# just a notification is sent to the Amazon SNS topic subscribers.

	else:
	    logger.info("The CloudTrail event was %s, sending email to the SNS topic subscribed" %eventname)

	    try:

	        #Sending the notification that a change has been made in AWS CloudTrail other than disabling it.
	        snspublish = snsclient.publish(
	                     TargetArn= snsARN,
	                     Subject=("CloudTrail event- \"%s\" received" %eventname),
	                     Message=json.dumps({'default': json.dumps(event)}),
	                     MessageStructure='json')
	        logger.debug("SNS Publish Response- %s" %snspublish)

	    except ClientError as e:
	       logger.error("An error occured: %s" %e)
