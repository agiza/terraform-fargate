### EBS Snapshot
### Lambda Setup
- [ ] IAM ROLE-NAME `ebs-snapshots-role`
- [ ] Create S3 bucket
- [ ] Lambda function
- [ ] Tagged Keypair `Backup / Yes`

Setting up the initial Lambda service includes permissions of the bucket where the function is going to be executed.
Setting up Lambda IAM
  - [ ] IAM ROLE-NAME `ebs-snapshots-role`
  - [ ] IAM POLICY-NAME `ebs-snapshots-policy`
Lambda function to create daily snapshots
`snapshot` ebs assets are automatically backed up daily using a cloudwatch trigger.

Navigate to IAM and create a New Role named `ebs-snapshots-role` select AWS Lambda as the role type

Attach a Policy to the IAM policy by pasting the `ebs-snapshots-policy.json` into the policy and name it `ebs-snapshots-policy`

**Note:**
The Lambda IAM role and policy provides the following permissions needed for Lambda.

- Retrieve information about volumes and snapshots from EC2
- Take new snapshots using the CreateSnapshot API call
- Delete snapshots using the DeleteSnapshot API call
- Write logs to CloudWatch for debugging


## Create volume Snapshot in Lambda
- [ ] Create Lambda function named `ebs-create-snapshots`
- [ ] Adjust Timeout
- [ ] Create Lambda trigger

Navigate to Lambda, Create a Lambda function:
Create a new function `ebs-create-snapshots` paste code within the code pane.
Select Handler labda_functoin.lambda_handler choose an existing role of `ebs-snapshots-role` under Advanced Settings adjust the time out to 1 min leaving the 128 mb as the memory available.
Select CloudWatch Events - Schedule
Create a rule `ebs-create-snapshots` with a daily run rule pasting the `ebs-create-snapshots`

## Delete volume Snapshots
- [ ] Create Lambda function named `ebs-delete-snapshot`
- [ ] Adjust Timeout `ebs-delete-snapshots`
- [ ] Schedule Lambda Trigger
Create a  new lambda function named `ebs-delete-snapshot` pasting the `ebs-delete-snapshot` lambda code.


## AMI Snapshot
- [ ] Tag the Instance in the EC2 console
- [ ] Create a key pair Tag Value Backup / yes
- [ ] Create a Lambda Function `create_amis`
- [ ] Add the create ami's lambda code

Navigate to EC2 Console
Tag each instance with ami backups with key value pair of Backup / yes
Navigate to Lambda and create a new Lambda Function
Add the create-amis nodejs code.
Three API's used are `describeInstances()` describes the filtered instance with key Backup/yes, `createImage()` create the filtered instances and `createTags()` which assisgns the tags with key DeleteOn to yes.
Create a Trigger `CloudWatch Events - Scheduled` give a name of `execute_at_12` `cron(30 18 ? * MON-FRI *)` enable the trigger to run at midnight and Submit

## AMI Deletion
- [ ] Create a Lambda Function `delete-amis`
- [ ] Add the delete-amis lambda code
- [ ] Schedule a Trigger

Navigatge to Lambda and create a new Lambda Function
Add `delete-amis` to lambda function
Three API's used are `describeImages()` filters on `DeleteOn` `yes` key tag value, `deregisterImage()` which deregisters the image and `deleteSnapshot()` which deletes on the filtered image.
