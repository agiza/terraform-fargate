# Install system packages
sudo yum install wget -y
sudo yum install unzip -y
# RHEL comes pre-installed with Python but we still need to install pip
curl -O https://bootstrap.pypa.io/get-pip.py
sudo python get-pip.py
# Install AWS CLI using pip
sudo pip install awscli
# Install Terraform 0.11.8
wget https://releases.hashicorp.com/terraform/0.11.8/terraform_0.11.8_linux_amd64.zip
unzip terraform_0.11.8_linux_amd64.zip
sudo cp terraform /usr/bin
# Install Vault
wget https://releases.hashicorp.com/vault/0.7.3/vault_0.7.3_linux_amd64.zip
unzip vault_0.7.3_linux_amd64.zip
sudo cp vault /usr/bin
# Install Packer
wget https://releases.hashicorp.com/packer/1.0.2/packer_1.0.2_linux_amd64.zip
unzip packer_1.0.2_linux_amd64.zip
sudo cp packer /usr/bin
# Install git
sudo yum install git -y
# Install OpenVPN
wget http://dl.fedoraproject.org/pub/epel/7/x86_64/e/epel-release-7-10.noarch.rpm
sudo rpm -ivh epel-release-7-10.noarch.rpm
sudo yum install openvpn -y
