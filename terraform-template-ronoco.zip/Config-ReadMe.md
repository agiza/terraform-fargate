# terraform-aws


# Configuration

1. Download and unzip terraform to C:\terraform
2. Add C:\terraform to PATH variable in system settings
3. Verify 'terraform -v' in powershell window
4. Create S3 bucket and folder to store the Terraform state (.tfstate)
5. Install [Winbox](https://github.com/adamedx/winbox) via PowerShell. This will install all the required devops related tools (Visual Studio code,Git,Chocolatey,ConEMU) to start your development. Make sure to update the VS code to latest version.
 > Linux users to install Git & IDE like VScode, Sublime, ATOM etc.
6. Install [terraform highlighter] (https://marketplace.visualstudio.com/items?itemName=mauve.terraform) plugin to Visual studio code.
7. VS Code -> Preferences -> Settings and add below snippet to support .tpl files
`{
    "files.associations": {
        "*.tpl": "json",
        "*.master": "html"
    }
}`
8. Install [AWS-ADFS](https://github.com/venth/aws-adfs) a Command line tool to easier aws cli authentication against ADFS (multi factor authentication with active directory).


## Terraform State config
Terraform records information about what infrastructure it created in a Terraform state file. By default, when you run Terraform in the folder /main/, Terraform creates the file /main/terraform.tfstate. This file contains a custom JSON format that records a mapping from the Terraform resources in your templates to the representation of those resources in the real world. Any discrepancies in the .tfstate file will break the infrastructure. Especially in real life, multi-member projects if two members are working on the same repo, unless the same .tfstate file is used, deployment will be inconsistent.

>> To resolve this issue, its recommended to store the state config in S3. All the project members need to run the below snippet to configure terraform to use the remote .tfstate file. Also encrypt the tfstate file to secure the any confidential info.

## Terraform State Isolation
When you first start using Terraform, you may be tempted to define all of your infrastructure in a single Terraform file or a set of Terraform files in one folder and change the variables for each environment. The problem with this approach is that all of your Terraform state is now stored in a single file for all the envionments and a mistake anywhere could break everything. For example, while trying to deploy a new version of your app in qa, you might break the app in prod.

>> To mitigate this issue, wrap all the common code using [modules](https://www.terraform.io/docs/modules/usage.html) functions in terraform, create a folder for each enviornment say Prod, Dev etc and run the `terraform remote config` on each folder. `plan.ps1`,`apply.ps1`, `destroy.ps1` is created for this purpose. This ensures tf state files are isolated for each environment.


## TFS and GIT integration
>> Make sure you have correct AWS credentials to execute these steps. Any mismatch in the AWS credentials (Eg: running with prod credentials instread of Lab) will result in the infrastucture changes to the Prod instead of Lab. We recommed to use password vault to store the AWS keys and use the keys on console directly instead of storing in as text.

 ![TF](./terraform-flow.png)

Incremental deployments to infrastructure is carried out via GIT branching structure and role based access control. Ops admins adds enhancements to existing code base and repo admin merges the changes and maintains the master branch.

1. Make sure GIT is installed and you have required permissions to TFS Git Repo
2. Clone the GIT repo.
`git clone http://tfsmain:8080/ConvergEx/ConvergexCloudServices_GITRepo`
3. This will download the latest repo. Now you can store your sensitive files (if any) in the /secrets folder. Any files under this folder will be ignored and will not be updated on TFS
4. After you made updates to the repo, run the below GIT commands to update the GIT repo

### To Add all the new files
`git add -A`

### To commit the new files
`git commit -m "Useful log message"`

### To push to Git repo
`git push`



## Project structure

1. Environment (Lab)
    1. plan.ps1 -> Script to refresh ADFS session tokens, configure remote state and Plan terraform
    2. apply.ps1 -> Script to refresh ADFS session tokens, configure remote state and apply terraform
    3. destroy.ps1 -> Script to refresh ADFS session tokens, configure remote state and destroy terraform
    4. main.tf -> Main
    5. variables.tf -> Store environment specific variables
2. Modules
    1. Module 1 (IAM)
        1. CreateBaselineIAMRoles -> main
        2. variables.tf -> mod variables helper.
        3. template_file.tf -> template loader
        4. xxxPolicy.tpl -> Policy templates (JSON)

## Usage

1. Clone this repo
2. Update and run init.ps1 on each folder with required bucket values.
>> Make sure you run this step every time you create a new folder or pull a new folder or when the access keys are changed.
3. Update <env>\<resource>\variables.tf with required env variables
4. `cd \lab1\vpc\`
5. `\plan.ps1`
6. `\apply.ps1`
7. `destroy.ps1`


### Get

The 'Get' command loads the modules referred in the main file.

```powershell
terraform get -update
```

### Plan

The plan phase takes your Terraform configuration and attempts to provide you with a plan of what it **would** do if you applied it. It outputs an execution plan to  `terraform.tfplan` file (not human-readable).

```powershell
terraform plan
terraform plan -out terraform.tfplan (optional)
```

### Apply

The apply phase simply takes the Terraform execution plan and attempts to execute it.

```powershell
terraform apply
```

### Destroy

The destroy phase happens in two steps. First, Terraform generates a destroy execution plan, and then applies it. It outputs an execution plan to `stdout` along a new `terraform.tfplan` file. After that, it attempts to apply the destroy execution plan.

```powershell
terraform destroy
```

**Note**: The `destroy` step usually has to be run more than once because of an issue with deleting the Elastic IP (EIP) before it is unbound from the NAT instance. Run `terraform destroy` again after the failure to complete the destroy phase.

## Next steps

Build modules for other standard AWS resources.

1. VPC
    1. Flow Logs
2. Storage
    1. Buckets
    2. Bucket policies
3. EC2
    1. Web Server
    2. DB servers
4. RDS
5. Logging

# Adding to project

>> If an AWS resource needs to be re-used with in the same account or created across all the accounts, wrap it in a module to avoid code duplication and to maintain consistency.

## To add a new module:
 1. Create a folder eg. /modules/VPC
 2. Add file for resource creation eg. CreateVPC.tf and variables.tf
 3. Add the code to create required AWS resources.(Reference)[https://www.terraform.io/docs/providers/aws/]
 4. To test the project, create a folder in test environment. (/lab1/vpc)
 5. Add below files
 6. main.tf -> Load the module created above and pass the variables
 7. variables.tf -> parameters for resource creation
 8. Modify plan.ps1,apply.ps1,destrpy.ps1 -> To initialize the remote state files
